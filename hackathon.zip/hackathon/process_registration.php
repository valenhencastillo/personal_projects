<?php
// process_registration.php - Procesar el registro
session_start();
require_once 'config.php';
require_once 'email_functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

try {
    // Validar datos recibidos
    $data = $_POST;
    $files = $_FILES;
    
    // Validar campos obligatorios
    $required_fields = ['fullName', 'docType', 'documentNumber', 'birthDate', 'gender', 'email', 'phone'];
    foreach ($required_fields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Campo requerido faltante: $field");
        }
    }
    
    // Verificar duplicados por cédula
    $stmt = $pdo->prepare("SELECT id FROM registrations WHERE document_number = ?");
    $stmt->execute([$data['documentNumber']]);
    if ($stmt->fetch()) {
        throw new Exception("Este documento ya está registrado");
    }
    
    // Calcular edad
    $birthDate = new DateTime($data['birthDate']);
    $today = new DateTime();
    $age = $today->diff($birthDate)->y;
    
    if ($age < 8 || $age > 20) {
        throw new Exception("La edad debe estar entre 8 y 20 años");
    }
    
    // Generar número de registro único
    $registration_number = 'HC2024-' . time() . rand(1000, 9999);
    
    // Procesar archivos subidos
    $document_photo_path = '';
    $authorization_doc_path = '';
    
    if (isset($files['documentPhoto']) && $files['documentPhoto']['error'] === 0) {
        $document_photo_path = uploadFile($files['documentPhoto'], 'documents/');
    }
    
    if (isset($files['authorizationDocument']) && $files['authorizationDocument']['error'] === 0) {
        $authorization_doc_path = uploadFile($files['authorizationDocument'], 'authorizations/');
    }
    
    // Insertar en base de datos
    $sql = "INSERT INTO registrations (
        registration_number, full_name, document_type, document_number, nationality,
        birth_date, age, gender, email, phone, address, state, city,
        institution, education_level, grade, category, microbit_experience,
        expectations, shirt_size, document_photo_path, is_minor,
        guardian_name, guardian_doc_type, guardian_document, guardian_email,
        guardian_phone, authorization_doc_path, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $registration_number,
        $data['fullName'],
        $data['docType'],
        $data['documentNumber'],
        $data['nationality'] ?? '',
        $data['birthDate'],
        $age,
        $data['gender'],
        $data['email'],
        $data['phone'],
        $data['address'],
        $data['state'],
        $data['city'],
        $data['institution'],
        $data['educationLevel'],
        $data['grade'],
        ($age <= 14) ? 'Junior' : 'Senior',
        $data['microbitExperience'],
        $data['expectations'] ?? '',
        $data['shirtSize'],
        $document_photo_path,
        ($age < 18) ? 1 : 0,
        $data['guardianName'] ?? '',
        $data['guardianDocType'] ?? '',
        $data['guardianDocument'] ?? '',
        $data['guardianEmail'] ?? '',
        $data['guardianPhone'] ?? '',
        $authorization_doc_path
    ]);
    
    // Generar código QR
    $qr_url = generateQRCode($registration_number);
    
    // Enviar emails de confirmación
    sendConfirmationEmail($data['email'], $data['fullName'], $registration_number, $qr_url);
    
    if (!empty($data['guardianEmail'])) {
        sendGuardianNotificationEmail($data['guardianEmail'], $data['guardianName'], $data['fullName'], $registration_number);
    }
    
    echo json_encode([
        'success' => true,
        'registration_number' => $registration_number,
        'qr_code' => $qr_url,
        'message' => 'Registro completado exitosamente'
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function uploadFile($file, $directory) {
    $uploadDir = 'uploads/' . $directory;
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $fileName = time() . '_' . basename($file['name']);
    $uploadPath = $uploadDir . $fileName;
    
    // Validar tipo de archivo
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!in_array($file['type'], $allowedTypes)) {
        throw new Exception('Tipo de archivo no permitido');
    }
    
    // Validar tamaño (5MB máximo)
    if ($file['size'] > 5 * 1024 * 1024) {
        throw new Exception('Archivo demasiado grande (máximo 5MB)');
    }
    
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        throw new Exception('Error al subir el archivo');
    }
    
    return $uploadPath;
}

function generateQRCode($registration_number) {
    // Usando API gratuita para generar QR
    return "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($registration_number);
}
?>