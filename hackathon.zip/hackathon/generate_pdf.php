<?php
// generate_pdf.php - Generar PDF de autorización
require_once 'vendor/autoload.php'; // Para TCPDF o similar

use TCPDF;

if ($_GET['action'] === 'download_authorization') {
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);
    
    $html = '
    <h1 style="text-align: center;">AUTORIZACIÓN PARA MENOR DE EDAD</h1>
    <h2 style="text-align: center;">Hackathon Cursos Cleveland 2024</h2>
    
    <p><strong>Yo, ___________________________________,</strong> mayor de edad, venezolano/a, 
    titular de la Cédula de Identidad N° __________________, 
    en mi carácter de <strong>REPRESENTANTE LEGAL</strong> del menor 
    <strong>___________________________________,</strong> 
    titular de la Cédula de Identidad N° __________________,</p>
    
    <p><strong>AUTORIZO EXPRESAMENTE</strong> la participación del menor antes mencionado 
    en el evento denominado <strong>"Hackathon Cursos Cleveland 2024"</strong> 
    a realizarse en las fechas y lugar que la organización establezca.</p>
    
    <h3>TÉRMINOS Y CONDICIONES:</h3>
    <ol>
        <li>Autorizo que el menor participe en todas las actividades programadas del evento.</li>
        <li>Exonero de toda responsabilidad a los organizadores por accidentes que puedan ocurrir durante el evento, salvo negligencia comprobada.</li>
        <li>Autorizo el uso de la imagen del menor en fotografías y videos del evento para fines promocionales y educativos.</li>
        <li>Me comprometo a que el menor cumpla con las normas de conducta establecidas.</li>
        <li>Proporciono los datos de contacto de emergencia: _____________________</li>
    </ol>
    
    <br><br>
    <p>Lugar: _________________ Fecha: _________________</p>
    
    <br><br>
    <table width="100%">
        <tr>
            <td width="50%" style="text-align: center;">
                _________________________<br>
                Firma del Representante
            </td>
            <td width="50%" style="text-align: center;">
                _________________________<br>
                Huella Dactilar
            </td>
        </tr>
    </table>
    
    <br>
    <p><small>Este documento debe ser llenado completamente, firmado y subido al sistema de registro.</small></p>
    ';
    
    $pdf->writeHTML($html);
    $pdf->Output('autorizacion_menor.pdf', 'D');
}
?>